class Chicken < ActiveRecord::Base

  

end
