module ChickensHelper
end
